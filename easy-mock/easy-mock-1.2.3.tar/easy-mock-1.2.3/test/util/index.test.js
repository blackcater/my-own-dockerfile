'use strict'

require('should')

describe('test/util/index.test.js', () => {})
